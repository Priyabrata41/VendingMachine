using Microsoft.Extensions.DependencyInjection;
using System;
using VendingMachine.Data.Access;
using VendingMachine_2._0.Handler;
using VendingMachine_2._0.Helpers;
using VendingMachine_2._0.Interfaces;

namespace VendingMachine_2._0
{
	class Program
	{
		static void Main(string[] args)
		{
      var serviceProvider = new ServiceCollection()
           .AddSingleton<IVendingMachine, VendingMachine_2._0.Helpers.VendingMachine>()
           .AddSingleton<IInventoryAccessor, InventoryAccessor>()
           .AddSingleton<ILogger, Logger>()
           .AddSingleton<IMoney, Money>()
           .BuildServiceProvider();
      Menu menu = new Menu(serviceProvider.GetService<IVendingMachine>());
      menu.Display();
    }
	}
}
