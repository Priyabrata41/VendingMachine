using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine_2._0.Interfaces
{
  public interface ILogger
  {
    public void Log(string message, decimal moneyBefore, decimal moneyAfter);
  }
}
