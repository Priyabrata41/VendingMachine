using System;
using System.Collections.Generic;
using VendingMachine.Data.Access;
using VendingMachine.Data.Access.Helpers;
using VendingMachine_2._0.Interfaces;

namespace VendingMachine_2._0.Helpers
{
  public class VendingMachine: IVendingMachine
  {
    private readonly ILogger _log;

    private readonly IInventoryAccessor _inventoryAccessor;
    public IMoney Money  { get; set; }
    public string NotEnoughMoneyError { get; private set; }
    public string MessageToUser;
    public Dictionary<string, VendingItem> VendingMachineItems { get;private set; }

    public VendingMachine(IInventoryAccessor inventoryAccessor, IMoney money, ILogger logger)
    {
      _inventoryAccessor = inventoryAccessor;
      Money = money;
      _log = logger;
      NotEnoughMoneyError = "Not enough money in the machine to complete the transaction.";
      VendingMachineItems = _inventoryAccessor.GetVendingItems();
    }

    public decimal MoneyInMachine
    {
      get
      {
        return Money.MoneyInMachine;
      }
    }

    

    public void DisplayAllItems()
    {
      Console.WriteLine($"\n\n{"#".PadRight(5)} {"Stock"} { "Product".PadRight(47) } { "Price".PadLeft(7)}");
      
      if(VendingMachineItems ==null || VendingMachineItems.Count==0)
      {
        Console.WriteLine($"No items in stock..");
        _log.Log($"No items received from inventory accessor", 0, 0);
      }
      foreach (KeyValuePair<string, VendingItem> kvp in VendingMachineItems)
      {
        if (kvp.Value.ItemsRemaining > 0)
        {
          string itemNumber = kvp.Key.PadRight(5);
          string itemsRemaining = kvp.Value.ItemsRemaining.ToString().PadRight(5);
          string productName = kvp.Value.ProductName.PadRight(40);
          string price = kvp.Value.Price.ToString("C").PadLeft(7);
          Console.WriteLine($"{itemNumber} {itemsRemaining} {productName} Costs: {price} each");
        }
        else
        {
          Console.WriteLine($"{kvp.Key}: {kvp.Value.ProductName} IS SOLD OUT.");
          _log.Log($"{kvp.Key}: {kvp.Value.ProductName} IS SOLD OUT.", 0, 0);
        }
      }
    }

    public bool ItemExists(string itemNumber)
    {
      return VendingMachineItems.ContainsKey(itemNumber);
    }

    public bool RetreiveItem(string itemNumber)
    {
      // If the item exists (not Q1 or something like that)
      // and we can remove the item
      // and we have more money in the machine than the price
    
        

      if (this.ItemExists(itemNumber)
          && Money.MoneyInMachine >= VendingMachineItems[itemNumber].Price
          && VendingMachineItems[itemNumber].ItemsRemaining > 0
          && VendingMachineItems[itemNumber].RemoveItem())
      {
        // Logging message "CANDYBARNAME A1"
        string message = $"{VendingMachineItems[itemNumber].ProductName.ToUpper()} {itemNumber}";

        // Logging before: current money in machine
        decimal before = Money.MoneyInMachine;

        // Remove the money
        Money.RemoveMoney(VendingMachineItems[itemNumber].Price);

        // Logging after: current money in machine
        decimal after = Money.MoneyInMachine;

        // Log the log
        _log.Log(message, before, after);

        return true;
      }
      else
      {
        return false;
      }
    }
  }
}
