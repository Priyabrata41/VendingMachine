using Moq;
using System;
using System.Collections.Generic;
using VendingMachine.Data.Access;
using VendingMachine.Data.Access.Helpers;
using VendingMachine.Data.Access.Models;
using VendingMachine_2._0.Interfaces;
using Xunit;
using ILogger = VendingMachine_2._0.Interfaces.ILogger;
using vm = VendingMachine_2._0.Helpers;

namespace VendingMachine_Tests
{
  public class VendingMachineTest
	{

    private readonly Mock<IInventoryAccessor> inventoryAccessorMock;
    private readonly Mock<IMoney> moneyMock;
    private readonly Mock<ILogger> loggerMock;
    private readonly vm.VendingMachine vendingMachine;

    public VendingMachineTest()
    {
      inventoryAccessorMock = new Mock<IInventoryAccessor>();
      moneyMock = new Mock<IMoney>();
      loggerMock = new Mock<ILogger>();
     
    }

    [Fact]
    public void Test_DisplayAllItems_WhenNoItemsPresent_ThrowsNullRefException()
    {
      //arrange
      var items = new Dictionary<string, VendingItem>();
      inventoryAccessorMock.Setup(x => x.GetVendingItems()).Returns(items);
      var vendingMachine = new vm.VendingMachine(inventoryAccessorMock.Object, moneyMock.Object, loggerMock.Object);


      //act
      vendingMachine.DisplayAllItems();

      //assert
      loggerMock.Verify(x => x.Log(It.IsAny<string>(), It.IsAny<decimal>(), It.IsAny<decimal>()), Times.Once);
    }

    [Fact]
    public void Test_DisplayAllItems_WhenItemsPresentWithNoStock_LogsMessage()
    {
      //arrange
      var items = new Dictionary<string, VendingItem>();
      items.Add("0",new Drink("demoDrink", 1, 0));
      inventoryAccessorMock.Setup(x => x.GetVendingItems()).Returns(items);

      //act
      vendingMachine.DisplayAllItems();

      //assert
      loggerMock.Verify(x => x.Log(It.IsAny<string>(), It.IsAny<decimal>(), It.IsAny<decimal>()), Times.Once);
    }

    [Fact]
    public void Test_DisplayAllItems_WhenItemsPresent_LogsMessage()
    {
      //arrange
      var items = new Dictionary<string, VendingItem>();
      items.Add("0", new Drink("demoDrink", 1, 1));
      inventoryAccessorMock.Setup(x => x.GetVendingItems()).Returns(items);

      //act
      vendingMachine.DisplayAllItems();

      //assert
      loggerMock.Verify(x => x.Log(It.IsAny<string>(), It.IsAny<decimal>(), It.IsAny<decimal>()), Times.Never);
    }

  }
}
