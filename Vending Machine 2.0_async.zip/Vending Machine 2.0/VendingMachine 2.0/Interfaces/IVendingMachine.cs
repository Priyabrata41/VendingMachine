using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VendingMachine.Data.Access.Helpers;

namespace VendingMachine_2._0.Interfaces
{
  public interface IVendingMachine
  {
    public void DisplayAllItems();
    public Task DisplayAllItemsAsync();
    public decimal MoneyInMachine { get; }
    public bool RetreiveItem(string itemNumber);
    public bool ItemExists(string itemNumber);
    public Dictionary<string, VendingItem> VendingMachineItems{ get; }
    public IMoney Money { get; }
    public string NotEnoughMoneyError { get; }
  }
}
