using System;
using System.Collections.Generic;
using System.Text;

namespace VendingMachine_2._0.Interfaces
{
  public interface IMoney
  {
    public decimal MoneyInMachine { get; }
    public bool AddMoney(string amount);
    public bool RemoveMoney(decimal amountToRemove);
    public string GiveChange();
  }
}
