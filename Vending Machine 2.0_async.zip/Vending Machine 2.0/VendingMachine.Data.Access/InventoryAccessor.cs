using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using VendingMachine.Data.Access.Helpers;
using VendingMachine.Data.Access.Models;

namespace VendingMachine.Data.Access
{
  public class InventoryAccessor : IInventoryAccessor
  {
    private const int Pos_itemNumber = 0;
    private const int Pos_ItemName = 1;
    private const int Pos_ItemPrice = 2;
    private const int Pos_itemType = 3;
    public Dictionary<string, VendingItem> GetVendingItems()
    {
      Dictionary<string, VendingItem> items = new Dictionary<string, VendingItem>();

      string file = string.Empty;
      var assembly = Assembly.GetExecutingAssembly();
      var resourceName = assembly.GetManifestResourceNames()
                         .Single(str => str.EndsWith("vendingmachine.csv"));
      if (assembly.GetManifestResourceStream(resourceName) != null)
      {

        try
        {
          using (Stream stream = assembly.GetManifestResourceStream(resourceName))
          {
            using (StreamReader sr = new StreamReader(stream))
            {
              while (!sr.EndOfStream)
              {
                // Read the line
                string line = sr.ReadLine();

                string[] itemDetails = line.Split("|");

                string itemName = itemDetails[Pos_ItemName];

                if (!decimal.TryParse(itemDetails[Pos_ItemPrice], out decimal itemPrice))
                {
                  itemPrice = 0M;
                }

                int itemsRemaining = 5;

                VendingItem item;

                switch (itemDetails[Pos_itemType])
                {
                  case "Drink":
                    item = new Drink(itemName, itemPrice, itemsRemaining);
                    break;
                  case "Candy":
                    item = new Candy(itemName, itemPrice, itemsRemaining);
                    break;

                  default:
                    item = new Candy(itemName, itemPrice, itemsRemaining);
                    break;
                }

                items.Add(itemDetails[Pos_itemNumber], item);
              }
            }
          }
        }
        catch (Exception ex)
        {
          Console.WriteLine("Error trying to open the input file.");
        }
      }
      else
      {
        Console.WriteLine("Input file is missing!! The vending machine will now self destruct.");
        items.Add("A1", new Drink("YOU BROKE IT!", 10000M, 5));
      }

      return items;
    }

    /// <summary>
    /// this method pretends to be a long running process.
    /// </summary>
    /// <returns></returns>
    public async Task<Dictionary<string, VendingItem>> GetVendingItemsAsync()
    {
     return await Task.Run(() =>
      {
        return GetVendingItems();
      });
    }
  }
}
