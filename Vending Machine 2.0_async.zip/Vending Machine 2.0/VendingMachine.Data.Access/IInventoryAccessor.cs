using System.Collections.Generic;
using System.Threading.Tasks;
using VendingMachine.Data.Access.Helpers;

namespace VendingMachine.Data.Access
{
  public interface IInventoryAccessor
	{
    Dictionary<string, VendingItem> GetVendingItems();
    Task<Dictionary<string, VendingItem>> GetVendingItemsAsync();
  }
}
